define({ "button.switch-metaview.tooltip": "Switch between meta and normal view" });
