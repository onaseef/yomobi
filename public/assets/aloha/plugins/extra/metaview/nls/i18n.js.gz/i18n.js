define({
	root: { "button.switch-metaview.tooltip": "Switch between meta and normal view" },
	"de":true,
	"en":true
});
