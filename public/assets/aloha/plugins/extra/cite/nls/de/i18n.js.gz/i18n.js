define({ "cite.button.add.quote": "Selektion als Zitat formatieren", "cite.button.add.blockquote": "Selektion als Blockzitat formatieren" });
