define({ "cite.button.add.quote": "Format selection as quote", "cite.button.add.blockquote": "Format selection as blockquote" });
