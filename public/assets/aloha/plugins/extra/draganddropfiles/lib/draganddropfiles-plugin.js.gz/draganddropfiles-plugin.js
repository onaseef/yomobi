define([ 'aloha', 'aloha/jquery', 'aloha/plugin', 'draganddropfiles/dragndropfiles'], 
function ( Aloha, jQuery, Plugin, DragNDrop) {
	return DragNDrop;
});
