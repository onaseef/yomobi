define({"button.addlink.tooltip":"Verweis einf\u00fcgen","button.removelink.tooltip":"Verweis entfernen","newlink.defaulttext":"Neuer Verweis","floatingmenu.tab.link":"Verweis"});
