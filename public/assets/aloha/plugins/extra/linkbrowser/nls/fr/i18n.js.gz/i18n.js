define({"button.addlink.tooltip":"Ins\u00e9rer un lien","button.removelink.tooltip":"Supprimer le lien","newlink.defaulttext":"Nouveau lien","floatingmenu.tab.link":"Lien"});
