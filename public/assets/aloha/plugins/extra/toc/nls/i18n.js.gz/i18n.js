define({
	root: {"button.addtoc.tooltip":"Table of contents"},
	"de":true
});
