define({"floatingmenu.tab.abbr":"Abk\u00fcrzung","button.addabbr.tooltip":"Abk\u00fcrzung einf\u00fcgen","button.abbr.tooltip":"Als Abk\u00fcrzung formatieren","newabbr.defaulttext":"Abb"});
