define( {
	'button.addlink.tooltip': 'Dodaj link',
	'button.removelink.tooltip': 'Usu\u0144 link',
	'newlink.defaulttext': 'Nowy link',
	'floatingmenu.tab.link': 'Link'
} );
