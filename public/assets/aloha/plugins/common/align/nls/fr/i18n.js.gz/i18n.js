define({"button.alignright.tooltip":"Aligner ï¿½ droite","button.alignleft.tooltip":"Aligner ï¿½ gauche","button.aligncenter.tooltip":"Centrer","button.alignjustify.tooltip":"Justifier"});
