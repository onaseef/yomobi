define({"button.alignright.tooltip":"Align to the right","button.alignleft.tooltip":"Align to the left","button.aligncenter.tooltip":"Center","button.alignjustify.tooltip":"Justify"});
