define({"button.createulist.tooltip":"Enmeti senordan liston","button.createolist.tooltip":"Enmeti ordan liston"});
