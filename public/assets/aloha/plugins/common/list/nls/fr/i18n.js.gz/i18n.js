define({"button.createulist.tooltip":"Ins\u00e9rer une liste non ordonn\u00e9e","button.createolist.tooltip":"Ins\u00e9rer liste ordonn\u00e9e"});
