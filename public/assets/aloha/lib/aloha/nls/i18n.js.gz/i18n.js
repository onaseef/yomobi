define( {
	'root':  {
		'plugin.abbr.floatingmenu.tab.abbr': 'Abbreviation',
		'floatingmenu.tab.format': 'Format',
		'floatingmenu.tab.insert': 'Insert',
		'yes': 'Yes',
		'no': 'No',
		'cancel': 'Cancel',
		'repository.no_item_found': 'No item found.',
		'repository.loading': 'Loading',
		'repository.no_items_found_yet': 'No items found yet...'
	},
	'de':  true
/*	'eo':  true,
	'fi':  true,
	'fr':  true,
	'it':  true,
	'pl':  true,
	'ru':  true*/
} );
